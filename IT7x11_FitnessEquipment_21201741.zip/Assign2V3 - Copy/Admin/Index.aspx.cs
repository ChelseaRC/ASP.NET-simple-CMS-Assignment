﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_Index : System.Web.UI.Page
{
    SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\USERS\21201741\DESKTOP\INTERNET APPLICATIONS\ASSIGN2V3\APP_DATA\DATABASE.MDF;Integrated Security=True");
    SqlCommand cmd = new SqlCommand();
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void ButtonLoginA_Click(object sender, EventArgs e)
    {
        Con.Open();

        cmd.Connection = Con;
        cmd.CommandText = "SELECT *FROM Admin WHERE username='" + TextBoxUsernameA.Text + "'AND password = '" + TextBoxPasswordA.Text + "'";
        dr = cmd.ExecuteReader();
        dr.Read();

        if (dr.HasRows)
        {

            Session["username"] = dr["username"].ToString();
            Response.Redirect("Home.aspx");
        }
        else
        {
            Response.Write("<script language='javascript'> alert('Login Failed. Please Try Again');</script>");
        }

        Con.Close();

    }
}