﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_News : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            fillList();
            buttonActive(false, true, false, false, false, false);
        }
        if (Session["username"] == null)
        {
            Response.Redirect("Index.aspx");
        }
        //FirstEntry();

    }

    protected void fillList()
    {
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM News", sqlConn);
        SqlDataReader MyDataReader;
        DropDownList1.Items.Clear();



        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            while (MyDataReader.Read())
            {
                ListItem newitem = new ListItem();
                newitem.Text = MyDataReader["id"] + ", " + MyDataReader["Title"];
                newitem.Value = MyDataReader["id"].ToString();
                DropDownList1.Items.Add(newitem);
            }


        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }
    }

    //protected void FirstEntry()
    //{
    //    buttonActive(false, true, false, true, false, true);

    //    SqlConnection sqlConn = new SqlConnection(MyConnStr);
    //    SqlCommand cmd = new SqlCommand("SELECT * FROM News WHERE Id='" + DropDownList1.SelectedValue + "'", sqlConn);
    //    SqlDataReader MyDataReader;

    //    try
    //    {
    //        sqlConn.Open();
    //        MyDataReader = cmd.ExecuteReader();
    //        MyDataReader.Read();

    //        TextBoxID.Text = MyDataReader["Id"].ToString();
    //        TextBoxTitle.Text = MyDataReader["Title"].ToString();
    //        TextBoxDescription.Text = MyDataReader["Description"].ToString();

    //        //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
    //    }
    //    catch (Exception er)
    //    {
    //        Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
    //        //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
    //    }
    //    finally
    //    {
    //        sqlConn.Close();
    //        //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
    //    }
    //}

    protected void buttonActive(bool Panel, bool btnAdd, bool btnInsert, bool btnEdit, bool btnUpdate, bool btnDelete)
    {
        Panel2.Enabled = Panel;
        ButtonAdd.Enabled = btnAdd;
        ButtonInsert.Enabled = btnInsert;
        ButtonEdit.Enabled = btnEdit;
        ButtonUpdate.Enabled = btnUpdate;
        ButtonDelete.Enabled = btnDelete;

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        buttonActive(false, true, false, true, false, true);

        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM News WHERE Id='" + DropDownList1.SelectedValue + "'", sqlConn);
        SqlDataReader MyDataReader;

        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();

            TextBoxID.Text = MyDataReader["Id"].ToString();
            TextBoxTitle.Text = MyDataReader["Title"].ToString();
            TextBoxDescription.Text = MyDataReader["Description"].ToString();

            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }

    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {

        buttonActive(true, false, true, false, false, false);
        TextBoxID.Text = "";
        TextBoxTitle.Text = "";
        TextBoxDescription.Text = "";


    }
    protected void ButtonInsert_Click(object sender, EventArgs e)
    {
 

        if (TextBoxTitle.Text == "")
        {
            TextBoxTitleValid.Visible = true;
            return;
        }
        if (TextBoxDescription.Text == "")
        {
            TextBoxDescriptionValid.Visible = true;
            return;
        }
        TextBoxTitleValid.Visible = false;
        TextBoxDescriptionValid.Visible = false;
        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("INSERT into News (Title,Description) values(@Title,@Description)", sqlConn);

        sqlcmd.Parameters.AddWithValue("@Title", TextBoxTitle.Text);
        sqlcmd.Parameters.AddWithValue("@Description", TextBoxDescription.Text);



        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Record has been added successfully');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            buttonActive(false, true, false, false, false, false);
            fillList();
            ClearPanel();
        }
    }
    protected void ButtonEdit_Click(object sender, EventArgs e)
    {
        buttonActive(true, false, false, false, true, false);
    }
    protected void ClearPanel()
    {
        TextBoxID.Text = "";
        TextBoxTitle.Text = "";
        TextBoxDescription.Text = "";

    }

    protected void ButtonUpdate_Click(object sender, EventArgs e)
    {
        if (TextBoxTitle.Text == "")
        {
            TextBoxTitleValid.Visible = true;
            return;
        }
        if (TextBoxDescription.Text == "")
        {
            TextBoxDescriptionValid.Visible = true;
            return;
        }
        TextBoxTitleValid.Visible = false;
        TextBoxDescriptionValid.Visible = false;

        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("UPDATE News SET Title=@Title,Description=@Description WHERE Id=@Id", sqlConn);
        sqlcmd.Parameters.AddWithValue("@Id", TextBoxID.Text);
        sqlcmd.Parameters.AddWithValue("@Title", TextBoxTitle.Text);
        sqlcmd.Parameters.AddWithValue("@Description", TextBoxDescription.Text);

        try
        {
          
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Record has been updated successfully');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            buttonActive(false, true, false, false, false, false);
            fillList();
        }

    }
    protected void ButtonDelete_Click(object sender, EventArgs e)
    {

        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("Delete from News where Id = @id", sqlConn);

        sqlcmd.Parameters.AddWithValue("@id", TextBoxID.Text);

        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Record has been deleted successfully');</script>");
            ClearPanel();
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            buttonActive(false, true, false, false, false, false);
            fillList();
        }
    }
}