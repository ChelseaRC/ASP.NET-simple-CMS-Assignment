﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Configuration;
using System.Net;

public partial class ContactUs : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        DataTable dt = new DataTable();
        string strQuery = "select ID, Phone, Address from Company";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }

    }

       
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (YourName.Text == "")
        {
            YourNameValidate.Visible = true;
            return;
        }
        if (YourEmail.Text == "")
        {
            YourEmailValidate.Visible = true;
            return;
        }
        if (YourEmail.Text == "")
        {
            YourEmailValidate.Visible = true;
            return;
        } 
        if (YourSubject.Text == "")
        {
            YourSubjectValidate.Visible = true;
            return;
        }
        if (Comments.Text == "")
        {
            CommentsValidate.Visible = true;
            return;
        }
        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("INSERT into Enquiries (Name, Email, Subject, Description) values(@Name, @Email, @Subject, @Description)", sqlConn);

        sqlcmd.Parameters.AddWithValue("@Name", YourName.Text);
        sqlcmd.Parameters.AddWithValue("@Email", YourEmail.Text);
        sqlcmd.Parameters.AddWithValue("@Subject", YourSubject.Text);
        sqlcmd.Parameters.AddWithValue("@Description", Comments.Text);



        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            DisplayMessage.Text = "Thank you for your enquiry";
            DisplayMessage.Visible = true;
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            YourSubject.Text = "";
            YourEmail.Text = "";
            YourName.Text = "";
            Comments.Text = "";
            sqlConn.Close();

        }
    }

}
