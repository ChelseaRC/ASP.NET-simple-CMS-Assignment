﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Admin_Customers : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            fillList();
            fillCities();
            buttonActive(false, true, false, false, false, false);
        }
        if (Session["username"] == null)
        {
            Response.Redirect("Index.aspx");
        }
        //FirstEntry();
    }

    //protected void FirstEntry()
    //{
    //    buttonActive(false, true, false, true, false, true);

    //    SqlConnection sqlConn = new SqlConnection(MyConnStr);
    //    SqlCommand cmd = new SqlCommand("SELECT * FROM Members WHERE Id='" + DropDownList1.SelectedValue + "'", sqlConn);
    //    SqlDataReader MyDataReader;

    //    try
    //    {
    //        sqlConn.Open();
    //        MyDataReader = cmd.ExecuteReader();
    //        MyDataReader.Read();

    //        TextBoxCusID.Text = MyDataReader["Id"].ToString();
    //        TextBoxFirstName.Text = MyDataReader["FirstName"].ToString();
    //        TextBoxLastName.Text = MyDataReader["LastName"].ToString();
    //        TextBoxDOB.Text = MyDataReader["DOB"].ToString();
    //        TextBoxAddress.Text = MyDataReader["Address"].ToString();
    //        TextBoxSuburb.Text = MyDataReader["Suburb"].ToString();
    //        TextBoxCity.Text = MyDataReader["City"].ToString();
    //        TextBoxZipCode.Text = MyDataReader["ZipCode"].ToString();
    //        TextBoxPhone.Text = MyDataReader["Phone"].ToString();
    //        TextBoxEmail.Text = MyDataReader["Email"].ToString();
    //        TextBoxUsername.Text = MyDataReader["Username"].ToString();
    //        TextBoxPassword.Text = MyDataReader["Password"].ToString();
    //        DropDownListHeardAbout.SelectedValue = MyDataReader["HearAboutUs"].ToString();
    //        DropDownListPrefferedContact.SelectedValue = MyDataReader["PrefferedContact"].ToString();

            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
    //    }
    //    catch (Exception er)
    //    {
    //        Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
    //        //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
    //    }
    //    finally
    //    {
    //        sqlConn.Close();
    //        //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
    //    }

    //}
    protected void fillList()
    {
        string ActiveOrNot = "Active";
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Members WHERE Active='" + ActiveOrNot + "'", sqlConn);
        SqlDataReader MyDataReader;
        DropDownList1.Items.Clear();
     

        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            while (MyDataReader.Read())
            {
                ListItem newitem = new ListItem();
                newitem.Text = MyDataReader["id"] + ", " + MyDataReader["FirstName"] + " " + MyDataReader["LastName"];
                newitem.Value = MyDataReader["id"].ToString();
                DropDownList1.Items.Add(newitem);
            }


        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }
    }

    protected void buttonActive(bool Panel, bool btnAdd, bool btnInsert, bool btnEdit, bool btnUpdate, bool btnDelete)
    {
        Panel2.Enabled = Panel;
        ButtonAdd.Enabled = btnAdd;
        ButtonInsert.Enabled = btnInsert;
        ButtonEdit.Enabled = btnEdit;
        ButtonUpdate.Enabled = btnUpdate;
        ButtonDelete.Enabled = btnDelete;

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        buttonActive(false, true, false, true, false, true);

        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Members WHERE Id='" + DropDownList1.SelectedValue + "'", sqlConn);
        SqlDataReader MyDataReader;
        

        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();


            TextBoxCusID.Text = MyDataReader["Id"].ToString();
            TextBoxFirstName.Text = MyDataReader["FirstName"].ToString();
            TextBoxLastName.Text = MyDataReader["LastName"].ToString();
            TextBoxDOB.Text = MyDataReader["DOB"].ToString();
            TextBoxAddress.Text = MyDataReader["Address"].ToString();
            TextBoxSuburb.Text = MyDataReader["Suburb"].ToString();
            TextBoxCity.Text = MyDataReader["City"].ToString();
            TextBoxZipCode.Text = MyDataReader["ZipCode"].ToString();;
            TextBoxPhone.Text = MyDataReader["Phone"].ToString();
            TextBoxEmail.Text = MyDataReader["Email"].ToString();
            TextBoxUsername.Text = MyDataReader["Username"].ToString();
            TextBoxPassword.Text = MyDataReader["Password"].ToString();
            DropDownList2.SelectedValue = DropDownList2.Items.FindByText(MyDataReader["City"].ToString()).Value;
            DropDownList2_SelectedIndexChanged(new object(), new EventArgs());
            DropDownList3.SelectedValue = DropDownList3.Items.FindByText(MyDataReader["Suburb"].ToString()).Value;
            DropDownListHeardAbout.SelectedValue = MyDataReader["HearAboutUs"].ToString();
            CheckBoxEmail.Checked = Convert.ToBoolean(MyDataReader["ContactEmail"]);
            CheckBoxPhone.Checked = Convert.ToBoolean(MyDataReader["ContactPhone"]);
            CheckBoxLetter.Checked = Convert.ToBoolean(MyDataReader["ContactLetter"]);

            



            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }

    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {

        buttonActive(true, false, true, false, false, false);
        TextBoxCusID.Text = "";
        TextBoxFirstName.Text = "";
        TextBoxLastName.Text = "";
        TextBoxDOB.Text = "";
        TextBoxAddress.Text = "";
        TextBoxZipCode.Text = "";
        TextBoxPhone.Text = "";
        TextBoxEmail.Text = "";
        TextBoxUsername.Text = "";
        TextBoxPassword.Text = "";
        TextBoxCity.Visible = false;
        TextBoxSuburb.Visible = false;
        DropDownList2.Visible = true;
        DropDownList3.Visible = true;
        

    }
    protected void ButtonInsert_Click(object sender, EventArgs e)
    {

        if (TextBoxFirstName.Text == "")
        {
            TextBoxFirstNameValid.Visible = true;
            return;
        }
        if (TextBoxLastName.Text == "")
        {
            TextBoxLastNameValid.Visible = true;
            return;
        }
        if (TextBoxDOB.Text == "")
        {
            TextBoxDOBValid.Visible = true;
            return;
        }
        if (TextBoxAddress.Text == "")
        {
            TextBoxAddressValid.Visible = true;
            return;
        }

        if (TextBoxZipCode.Text == "")
        {
            TextBoxZipCodeValid.Visible = true;
            return;
        }
        if (TextBoxPhone.Text == "")
        {
            TextBoxPhoneValid.Visible = true;
            return;
        }
        if (TextBoxEmail.Text == "")
        {
            TextBoxEmailValid.Visible = true;
            return;
        }
        if (TextBoxUsername.Text == "")
        {
            TextBoxUsernameValid.Visible = true;
            return;
        }
        if (TextBoxPassword.Text == "")
        {
            TextBoxPasswordValid.Visible = true;
            return;
        }
        TextBoxPhoneValid.Visible = false;
        TextBoxAddressValid.Visible = false;
        TextBoxPhoneValid.Visible = false;
        TextBoxAddressValid.Visible = false;
        TextBoxPhoneValid.Visible = false;
        TextBoxAddressValid.Visible = false;
        TextBoxPhoneValid.Visible = false;
        TextBoxAddressValid.Visible = false;
        TextBoxPhoneValid.Visible = false;
        TextBoxAddressValid.Visible = false;
        TextBoxAddressValid.Visible = false;
        TextBoxCity.Visible = true;
        TextBoxSuburb.Visible = true;
        DropDownList2.Visible = false;
        DropDownList3.Visible = false;


        string sqlFormattedDate = (Convert.ToDateTime(TextBoxDOB.Text)).ToString("yyyy-MM-dd HH:mm:ss");

        string MakeActive = "Active";
        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("INSERT into Members (FirstName,LastName,DOB,Address,Suburb,City,ZipCode,Phone,Email,Username,Password,HearAboutUs,ContactEmail,ContactPhone,ContactLetter,Active) values(@FirstName,@LastName,@DOB,@Address,@Suburb,@City,@ZipCode,@Phone,@Email,@Username,@Password,@HearAboutUs,@ContactEmail,@ContactPhone,@ContactLetter,@Active)", sqlConn);

        sqlcmd.Parameters.AddWithValue("@FirstName", TextBoxFirstName.Text);
        sqlcmd.Parameters.AddWithValue("@LastName", TextBoxLastName.Text);
        sqlcmd.Parameters.AddWithValue("@DOB", sqlFormattedDate);
        sqlcmd.Parameters.AddWithValue("@Address", TextBoxAddress.Text);
        sqlcmd.Parameters.AddWithValue("@Suburb", DropDownList3.SelectedItem.ToString());
        sqlcmd.Parameters.AddWithValue("@City", DropDownList2.SelectedItem.ToString());
        sqlcmd.Parameters.AddWithValue("@ZipCode", TextBoxZipCode.Text);
        sqlcmd.Parameters.AddWithValue("@Phone", TextBoxPhone.Text);
        sqlcmd.Parameters.AddWithValue("@Email", TextBoxEmail.Text);
        sqlcmd.Parameters.AddWithValue("@Username", TextBoxUsername.Text);
        sqlcmd.Parameters.AddWithValue("@Password", TextBoxPassword.Text);
        sqlcmd.Parameters.AddWithValue("@HearAboutUs", DropDownListHeardAbout.SelectedValue);
        sqlcmd.Parameters.AddWithValue("@ContactEmail", CheckBoxEmail.Checked);
        sqlcmd.Parameters.AddWithValue("@ContactPhone", CheckBoxPhone.Checked);
        sqlcmd.Parameters.AddWithValue("@ContactLetter", CheckBoxLetter.Checked);
        sqlcmd.Parameters.AddWithValue("@Active", MakeActive);


        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Record has been added successfully');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            buttonActive(false, true, false, false, false, false);
            fillList();
            ClearPanel();
        }
    }
    protected void ButtonEdit_Click(object sender, EventArgs e)
    {
        buttonActive(true, false, false, false, true, false);
        TextBoxCity.Visible = false;
        TextBoxSuburb.Visible = false;
        DropDownList2.Visible = true;
        DropDownList3.Visible = true;
    }
    protected void ClearPanel()
    {
        TextBoxCusID.Text = "";
        TextBoxFirstName.Text = "";
        TextBoxLastName.Text = "";
        TextBoxDOB.Text = "";
        TextBoxAddress.Text = "";

        TextBoxZipCode.Text = "";
        TextBoxPhone.Text = "";
        TextBoxEmail.Text = "";
        TextBoxUsername.Text = "";
        TextBoxPassword.Text = "";
        DropDownListHeardAbout.SelectedValue = "";
        CheckBoxEmail.Checked = false;
        CheckBoxPhone.Checked = false;
        CheckBoxLetter.Checked = false;

    }

    protected void ButtonUpdate_Click(object sender, EventArgs e)
    {

        if (TextBoxFirstName.Text == "")
        {
            TextBoxFirstNameValid.Visible = true;
            return;
        }
        if (TextBoxLastName.Text == "")
        {
            TextBoxLastNameValid.Visible = true;
            return;
        }
        if (TextBoxDOB.Text == "")
        {
            TextBoxDOBValid.Visible = true;
            return;
        }
        if (TextBoxAddress.Text == "")
        {
            TextBoxAddressValid.Visible = true;
            return;
        }

        if (TextBoxZipCode.Text == "")
        {
            TextBoxZipCodeValid.Visible = true;
            return;
        }
        if (TextBoxPhone.Text == "")
        {
            TextBoxPhoneValid.Visible = true;
            return;
        }
        TextBoxCity.Visible = true;
        TextBoxSuburb.Visible = true;
        DropDownList2.Visible = false;
        DropDownList3.Visible = false;
        string sqlFormattedDate = (Convert.ToDateTime(TextBoxDOB.Text)).ToString("yyyy-MM-dd HH:mm:ss");


        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("UPDATE Members SET FirstName=@FirstName,LastName=@LastName,DOB=@DOB,Address=@Address,Suburb=@Suburb,City=@City,ZipCode=@ZipCode,Phone=@Phone,Email=@Email,Username=@Username,Password=@Password,HearAboutUs=@HearAboutUs,ContactEmail=@ContactEmail,ContactPhone=@ContactPhone,ContactLetter=@ContactLetter WHERE Id=@Id", sqlConn);
       
        sqlcmd.Parameters.AddWithValue("@Id", TextBoxCusID.Text);
        sqlcmd.Parameters.AddWithValue("@FirstName", TextBoxFirstName.Text);
        sqlcmd.Parameters.AddWithValue("@LastName", TextBoxLastName.Text);
        sqlcmd.Parameters.AddWithValue("@DOB", sqlFormattedDate);
        sqlcmd.Parameters.AddWithValue("@Address", TextBoxAddress.Text);
        sqlcmd.Parameters.AddWithValue("@Suburb", DropDownList3.SelectedItem.ToString());
        sqlcmd.Parameters.AddWithValue("@City", DropDownList2.SelectedItem.ToString());
        sqlcmd.Parameters.AddWithValue("@ZipCode", TextBoxZipCode.Text);
        sqlcmd.Parameters.AddWithValue("@Phone", TextBoxPhone.Text);
        sqlcmd.Parameters.AddWithValue("@Email", TextBoxEmail.Text);
        sqlcmd.Parameters.AddWithValue("@Username", TextBoxUsername.Text);
        sqlcmd.Parameters.AddWithValue("@Password", TextBoxPassword.Text);
        sqlcmd.Parameters.AddWithValue("@HearAboutUs", DropDownListHeardAbout.SelectedValue);
        sqlcmd.Parameters.AddWithValue("@ContactEmail", CheckBoxEmail.Checked);
        sqlcmd.Parameters.AddWithValue("@ContactPhone", CheckBoxPhone.Checked);
        sqlcmd.Parameters.AddWithValue("@ContactLetter", CheckBoxLetter.Checked);
        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Record has been updated successfully');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            buttonActive(false, true, false, false, false, false);
            fillList();
        }

    }
    protected void ButtonDelete_Click(object sender, EventArgs e)
    {

        string Delete = "Inactive";
        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("UPDATE Members SET Active=@Active WHERE Id=@Id", sqlConn);
        sqlcmd.Parameters.AddWithValue("@Id", TextBoxCusID.Text);
        sqlcmd.Parameters.AddWithValue("@Active", Delete);


        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Customer has been Set to Inactive');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            //buttonActive(false, true, false, false, false, false);
            fillList();
        }


    }
    public void fillCities()
    {
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Cities", sqlConn);
        SqlDataReader MyDataReader;
        DropDownList2.Items.Clear();
        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            while (MyDataReader.Read())
            {
                ListItem newitem = new ListItem();
                newitem.Text = MyDataReader["City"].ToString();
                newitem.Value = MyDataReader["City_Id"].ToString();
                DropDownList2.Items.Add(newitem);
            }
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }


    }
    public void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Towns WHERE City_Id = '" + DropDownList2.SelectedValue + "'", sqlConn);
        SqlDataReader MyDataReader;
        DropDownList3.Items.Clear();
        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            while (MyDataReader.Read())
            {
                ListItem newitem = new ListItem();
                newitem.Text = MyDataReader["Town"].ToString();
                newitem.Value = MyDataReader["Town"].ToString();
                DropDownList3.Items.Add(newitem);
            }
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }
        this.DropDownList3.Enabled = true;
    }



}
