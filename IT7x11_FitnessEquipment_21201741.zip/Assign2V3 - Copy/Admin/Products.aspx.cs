﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class Admin_Products : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            fillList();
            buttonActive(false, true, false, false, false, false);
        }
        FileUpload1.Visible = false;
        if (Session["username"] == null)
        {
            Response.Redirect("Index.aspx");
        }
        //FirstEntry();
    }

    //protected void FirstEntry()
    //{
    //    buttonActive(false, true, false, true, false, true);

    //    SqlConnection sqlConn = new SqlConnection(MyConnStr);
    //    SqlCommand cmd = new SqlCommand("SELECT * FROM Products WHERE Id='" + DropDownList1.SelectedValue + "'", sqlConn);
    //    SqlDataReader MyDataReader;

    //    try
    //    {
    //        sqlConn.Open();
    //        MyDataReader = cmd.ExecuteReader();
    //        MyDataReader.Read();

    //        TextBoxID.Text = MyDataReader["Id"].ToString();
    //        TextBoxName.Text = MyDataReader["Name"].ToString();
    //        TextBoxDescription.Text = MyDataReader["Description"].ToString();
    //        TextBoxPrice.Text = MyDataReader["Price"].ToString();
    //        DropDownList2.SelectedValue = MyDataReader["Category"].ToString();
    //        DropDownList3.SelectedValue = MyDataReader["SubCategory"].ToString();
    //        FileUpload1.Visible = false;
    //        string id = TextBoxID.Text;
    //        Image1.Visible = id != "0";
    //        if (id != "0")
    //        {
    //            byte[] bytes = (byte[])GetData("SELECT Data FROM Products WHERE Id =" + id).Rows[0]["Data"];
    //            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
    //            Image1.ImageUrl = "data:image/png;base64," + base64String;
    //        }


    //        //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
    //    }
    //    catch (Exception er)
    //    {
    //        Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
    //        //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
    //    }
    //    finally
    //    {
    //        sqlConn.Close();
    //        //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
    //    }
    //}
    protected void fillList()
    {
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Products", sqlConn);
        SqlDataReader MyDataReader;
        DropDownList1.Items.Clear();



        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            while (MyDataReader.Read())
            {
                ListItem newitem = new ListItem();
                newitem.Text = MyDataReader["Name"].ToString();
                newitem.Value = MyDataReader["id"].ToString();
                DropDownList1.Items.Add(newitem);
            }


        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }
    }

    protected void buttonActive(bool Panel, bool btnAdd, bool btnInsert, bool btnEdit, bool btnUpdate, bool btnDelete)
    {
        Panel2.Enabled = Panel;
        ButtonAdd.Enabled = btnAdd;
        ButtonInsert.Enabled = btnInsert;
        ButtonEdit.Enabled = btnEdit;
        ButtonUpdate.Enabled = btnUpdate;
        ButtonDelete.Enabled = btnDelete;

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        buttonActive(false, true, false, true, false, true);

        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Products WHERE Id='" + DropDownList1.SelectedValue + "'", sqlConn);
        SqlDataReader MyDataReader;

        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();

            TextBoxID.Text = MyDataReader["Id"].ToString();
            TextBoxName.Text = MyDataReader["Name"].ToString();
            TextBoxDescription.Text = MyDataReader["Description"].ToString();
            TextBoxPrice.Text = MyDataReader["Price"].ToString();
            DropDownList2.SelectedValue= MyDataReader["Category"].ToString();
            DropDownList3.SelectedValue = MyDataReader["SubCategory"].ToString();
            FileUpload1.Visible = false;
            string id = TextBoxID.Text;
            Image1.Visible = id != "0";
            if (id != "0")
            {
                byte[] bytes = (byte[])GetData("SELECT Data FROM Products WHERE Id =" + id).Rows[0]["Data"];
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                Image1.ImageUrl = "data:image/png;base64," + base64String;
            }


            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }

    }
    private DataTable GetData(string query)
    {
        DataTable dt = new DataTable();
        using (SqlConnection con = new SqlConnection(MyConnStr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    sda.Fill(dt);
                }
            }
            return dt;
        }
    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        Image1.Visible = false;
        FileUpload1.Visible = true;
        buttonActive(true, false, true, false, false, false);
        TextBoxID.Text = "";
        TextBoxName.Text = "";
        TextBoxDescription.Text = "";
        TextBoxPrice.Text = "";



    }
    protected void ButtonInsert_Click(object sender, EventArgs e)
    {
        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("INSERT into Products (Name, Description, Price, PictureName, ContentType, Data, Category, SubCategory) values(@Name, @Description, @Price, @PictureName, @ContentType, @Data, @Category, @SubCategory)", sqlConn);

        sqlcmd.Parameters.AddWithValue("@Name", TextBoxName.Text);
        sqlcmd.Parameters.AddWithValue("@Description", TextBoxDescription.Text);
        sqlcmd.Parameters.AddWithValue("@Price", TextBoxPrice.Text);
        sqlcmd.Parameters.AddWithValue("@Category", DropDownList2.SelectedValue);
        sqlcmd.Parameters.AddWithValue("@SubCategory", DropDownList3.SelectedValue);


        {
            // Read the file and convert it to Byte Array
            string filePath = FileUpload1.PostedFile.FileName;
            string filename = Path.GetFileName(filePath);
            string ext = Path.GetExtension(filename);
            string contenttype = String.Empty;

            //Set the contenttype based on File Extension
            switch (ext)
            {

                case ".jpg":
                    contenttype = "image/jpg";
                    break;
                case ".png":
                    contenttype = "image/png";
                    break;
                case ".gif":
                    contenttype = "image/gif";
                    break;
                case ".pdf":
                    contenttype = "application/pdf";
                    break;
            }
            if (contenttype != String.Empty)
            {

                Stream fs = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                Byte[] bytes = br.ReadBytes((Int32)fs.Length);

                //insert the file into database
                //string strQuery = "insert into Products(PictureName, ContentType, Data)" +
                //   " values (@PictureName, @ContentType, @Data)";
                //SqlCommand cmd = new SqlCommand(strQuery);
                sqlcmd.Parameters.Add("@PictureName", SqlDbType.VarChar).Value = filename;
                sqlcmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
                sqlcmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;
                //InsertUpdateData(cmd);
            }
            else
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "File format not recognised." +
                  " Upload .Jpg/.Gif/.Png formats";
                return;
            }
        }


        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Record has been added successfully');</script>");

        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            buttonActive(false, true, false, false, false, false);
            fillList();
            ClearPanel();
        }
    }
    protected void ButtonEdit_Click(object sender, EventArgs e)
    {
        buttonActive(true, false, false, false, true, false);
        FileUpload1.Visible = false;

    }
    protected void ClearPanel()
    {
        TextBoxID.Text = "";
        TextBoxName.Text = "";
        TextBoxDescription.Text = "";
        TextBoxPrice.Text = "";

    }


    protected void ButtonUpdate_Click(object sender, EventArgs e)
    {
        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("UPDATE Products SET Name=@Name,Description=@Description, Price=@Price, Category=@Category, SubCategory=@SubCategory WHERE Id=@Id", sqlConn);
        sqlcmd.Parameters.AddWithValue("@Id", TextBoxID.Text);
        sqlcmd.Parameters.AddWithValue("@Name", TextBoxName.Text);
        sqlcmd.Parameters.AddWithValue("@Description", TextBoxDescription.Text);
        sqlcmd.Parameters.AddWithValue("@Price", TextBoxPrice.Text);
        sqlcmd.Parameters.AddWithValue("@Category", DropDownList2.SelectedValue);
        sqlcmd.Parameters.AddWithValue("@SubCategory", DropDownList3.SelectedValue);

        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Record has been updated successfully');</script>");

        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            buttonActive(false, true, false, false, false, false);
            fillList();
        }

    }
    protected void ButtonDelete_Click(object sender, EventArgs e)
    {

        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("Delete from Products where Id = @id", sqlConn);

        sqlcmd.Parameters.AddWithValue("@id", TextBoxID.Text);

        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'> alert('Record has been deleted successfully');</script>");
            ClearPanel();
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            buttonActive(false, true, false, false, false, false);
            fillList();
        }

    }

    //    private Boolean InsertUpdateData(SqlCommand cmd)
    //{
    //    String strConnString = System.Configuration.ConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;
    //    SqlConnection con = new SqlConnection(MyConnStr);
    //    cmd.CommandType = CommandType.Text;
    //    cmd.Connection = con;
    //    try
    //    {
    //        con.Open();
    //        cmd.ExecuteNonQuery();
    //        return true;
    //    }
    //    catch (Exception ex)
    //    {
    //        Response.Write(ex.Message);
    //        return false;
    //    }
    //    finally
    //    {
    //        con.Close();
    //        con.Dispose();
    //    }
    //}

    public bool True { get; set; }
}