﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Register : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            filllist();
        }
    }
    protected void ButtonRegister_Click(object sender, EventArgs e)
    {
        if (TextBoxFirstName.Text == "")
        {
            TextBoxFirstNameValidate.Visible = true;
            return;
        }
        if (TextBoxLastName.Text == "")
        {
            TextBoxLastNameValidate.Visible = true;
            return;
        }
        if (TextBoxDOB.Text == "")
        {
            TextBoxDOBValidate.Visible = true;
            return;
        }
        if (TextBoxAddress.Text == "")
        {
            TextBoxAddressValidate.Visible = true;
            return;
        }
        if (TextBoxZipCode.Text == "")
        {
            TextBoxZipCodeValidate.Visible = true;
            return;
        }
        if (TextBoxPhone.Text == "")
        {
            TextBoxPhoneValidate.Visible = true;
            return;
        }
        if (TextBoxEmail.Text == "")
        {
            TextBoxEmailValidate.Visible = true;
            return;
        }
        if (TextBoxUsername.Text == "")
        {
            TextBoxUsernameValidate.Visible = true;
            return;
        }
        if (TextBoxPassword.Text == "")
        {
            TextBoxPasswordValidate.Visible = true;
            return;
        }
       
        string MakeActive = "Active";

        string sqlFormattedDate = (Convert.ToDateTime(TextBoxDOB.Text)).ToString("yyyy-MM-dd HH:mm:ss");
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("INSERT into Members (FirstName,LastName,DOB,Address,Suburb,City,ZipCode,Phone,Email,Username,Password,HearAboutUs,ContactEmail,ContactPhone,ContactLetter,Active) values(@FirstName,@LastName,@DOB,@Address,@Suburb,@City,@ZipCode,@Phone,@Email,@Username,@Password,@HearAboutUs,@ContactEmail,@ContactPhone,@ContactLetter,@Active)", sqlConn);

        sqlcmd.Parameters.AddWithValue("@FirstName", TextBoxFirstName.Text);
        sqlcmd.Parameters.AddWithValue("@LastName", TextBoxLastName.Text);
        sqlcmd.Parameters.AddWithValue("@DOB", sqlFormattedDate);
        sqlcmd.Parameters.AddWithValue("@Address", TextBoxAddress.Text);
        sqlcmd.Parameters.AddWithValue("@Suburb", DropDownList2.SelectedItem.ToString());
        sqlcmd.Parameters.AddWithValue("@City", DropDownList1.SelectedItem.ToString());
        sqlcmd.Parameters.AddWithValue("@ZipCode", TextBoxZipCode.Text);
        sqlcmd.Parameters.AddWithValue("@Phone", TextBoxPhone.Text);
        sqlcmd.Parameters.AddWithValue("@Email", TextBoxEmail.Text);
        sqlcmd.Parameters.AddWithValue("@Username", TextBoxUsername.Text);
        sqlcmd.Parameters.AddWithValue("@Password", TextBoxPassword.Text);
        sqlcmd.Parameters.AddWithValue("@HearAboutUs", DropDownListHearAbout.SelectedValue);
        sqlcmd.Parameters.AddWithValue("@ContactEmail", CheckBoxEmail.Checked);
        sqlcmd.Parameters.AddWithValue("@ContactPhone", CheckBoxPhone.Checked);
        sqlcmd.Parameters.AddWithValue("@ContactLetter", CheckBoxLetter.Checked);
        sqlcmd.Parameters.AddWithValue("@Active", MakeActive);



        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'>window.alert('Thank you for registering! You can now login!');window.location='Login.aspx';</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();

        }
    }
    public void filllist()
    {
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Cities", sqlConn);
        SqlDataReader MyDataReader;
        DropDownList1.Items.Clear();
        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            while (MyDataReader.Read())
            {
                ListItem newitem = new ListItem();
                newitem.Text = MyDataReader["City"].ToString();
                newitem.Value = MyDataReader["City_Id"].ToString();
                DropDownList1.Items.Add(newitem);
            }
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }


    }

    public void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Towns WHERE City_Id = '" + DropDownList1.SelectedValue + "'", sqlConn);
        SqlDataReader MyDataReader;
        DropDownList2.Items.Clear();
        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            while (MyDataReader.Read())
            {
                ListItem newitem = new ListItem();
                newitem.Text = MyDataReader["Town"].ToString();
                newitem.Value = MyDataReader["Town"].ToString();
                DropDownList2.Items.Add(newitem);
            }
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }
        this.DropDownList2.Enabled = true;
    }

}