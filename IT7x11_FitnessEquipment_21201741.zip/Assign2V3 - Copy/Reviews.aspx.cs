﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Configuration;

public partial class Reviews : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        BindingData();
        if (Session["username"] == null)
        {
            Response.Write("<script language='javascript'>window.alert('You need to be logged in to see and place feedback.');window.location='Login.aspx';</script>");

        }
    }
    protected void ButtonInsert_Click(object sender, EventArgs e)
    {
        if (TextBoxName.Text == "")
        {
            TextBoxNameValidate.Visible = true;
            return;
        }
        if (TextBoxDescription.Text == "")
        {
            TextBoxDescriptionValidate.Visible = true;
            return;
        }
        string MakeActive = "Visible";
        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("INSERT into Feedback (Name,Description,Active) values(@Name,@Description,@Active)", sqlConn);

        sqlcmd.Parameters.AddWithValue("@Name", TextBoxName.Text);
        sqlcmd.Parameters.AddWithValue("@Description", TextBoxDescription.Text);
        sqlcmd.Parameters.AddWithValue("@Active", MakeActive);

        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            Label1.Visible = true;
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
            ClearPanel();


        }
    }
    protected void ClearPanel()
    {

        TextBoxName.Text = "";
        TextBoxDescription.Text = "";
        Label1.Visible = true;

        Response.Redirect(Request.RawUrl);



    }
    protected void BindingData()
    {
        if (!this.IsPostBack)
        {
            //Populating a DataTable from database.
            DataTable dt = this.GetData();

            //Building an HTML string.
            StringBuilder html = new StringBuilder();

            //Table start.
            html.Append("<table border = '0' cellspacing='0' style = 'font-size:16px; border: 1px solid black;'>");

            //Building the Header row.
            html.Append("<tr>");
            foreach (DataColumn column in dt.Columns)
            {
                html.Append("<th style = 'padding:10px; border-bottom: 1px solid black; margin-left:20px;'>");
                html.Append(column.ColumnName);
                html.Append("</th>");
            }
            html.Append("</tr>");

            //Building the Data rows.
            foreach (DataRow row in dt.Rows)
            {
                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<td style = 'padding:10px; border-bottom: 1px solid black; '>");
                    html.Append(row[column.ColumnName]);
                    html.Append("</td>");
                }
                html.Append("</tr>");
            }

            //Table end.
            html.Append("</table>");

            //Append the HTML string to Placeholder.
            PlaceHolderReviews.Controls.Add(new Literal { Text = html.ToString() });
        }
    }
    private DataTable GetData()
    {
        string ActiveOrNot = "Visible";
        using (SqlConnection con = new SqlConnection(MyConnStr))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT Name, Description FROM Feedback WHERE Active= '" + ActiveOrNot + "'"))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }
    }

}