﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterUser : System.Web.UI.MasterPage
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Login.Visible = true;
            Register.Visible = true;
            Logout.Visible = false;
            EditProfile.Visible = false;
        }
        else
        {
            Login.Visible = false;
            Register.Visible = false;
            Logout.Visible = true;
            EditProfile.Visible = true;


        }
    }
    protected void ButtonLogin_Click(object sender, EventArgs e)
    {

        if (TextBoxUsername.Text == "")
        {
            TextBoxUsernameValidate.Visible = true;
            return;
        }
        if (TextBoxPassword.Text == "")
        {
            TextBoxPasswordValidate.Visible = true;
            return;
        }
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT *FROM Members WHERE username='" + TextBoxUsername.Text + "'AND password = '" + TextBoxPassword.Text + "'", sqlConn);
        SqlDataReader MyDataReader;



        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();
            if (MyDataReader.HasRows)
            {

                Session["username"] = MyDataReader["username"].ToString();
                Session["UserId"] = MyDataReader["id"].ToString();
                Response.Redirect("Index.aspx");
            }
            else
            {
                Response.Write("<script language='javascript'> alert('Login Failed. Please Try Again');</script>");
            }

        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }
    }
}
