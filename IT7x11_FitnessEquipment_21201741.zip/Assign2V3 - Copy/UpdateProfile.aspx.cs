﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class UpdateProfile : System.Web.UI.Page
{    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Response.Write("<script language='javascript'>window.alert('You need to be logged in to see your profile.');window.location='Login.aspx';</script>");

        }
        else
        {
            if (!Page.IsPostBack)
            {
                AddData();
            }
        }
     

    }
    protected void AddData()
    {

        int UserId = Convert.ToInt32(Session["UserId"]); 
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Members WHERE Id='" + UserId + "'", sqlConn);
        SqlDataReader MyDataReader;

        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();

            TextBoxFirstName.Text = MyDataReader["FirstName"].ToString();
            TextBoxLastName.Text = MyDataReader["LastName"].ToString();
            TextBoxDOB.Text = MyDataReader["DOB"].ToString();
            TextBoxAddress.Text = MyDataReader["Address"].ToString();
            TextBoxSuburb.Text = MyDataReader["Suburb"].ToString();
            TextBoxCity.Text = MyDataReader["City"].ToString();
            TextBoxZipCode.Text = MyDataReader["ZipCode"].ToString();
            TextBoxPhone.Text = MyDataReader["Phone"].ToString();
            TextBoxEmail.Text = MyDataReader["Email"].ToString();
            TextBoxUsername.Text = MyDataReader["Username"].ToString();
            TextBoxPassword.Text = MyDataReader["Password"].ToString();
            DropDownListHearAbout.SelectedValue = MyDataReader["HearAboutUs"].ToString();
            CheckBoxEmail.Checked = Convert.ToBoolean(MyDataReader["ContactEmail"]);
            CheckBoxPhone.Checked = Convert.ToBoolean(MyDataReader["ContactPhone"]);
            CheckBoxLetter.Checked = Convert.ToBoolean(MyDataReader["ContactLetter"]);




            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }

    }
    protected void ButtonRegister_Click(object sender, EventArgs e)
    {
        string sqlFormattedDate = (Convert.ToDateTime(TextBoxDOB.Text)).ToString("yyyy-MM-dd HH:mm:ss");

        int ID = Convert.ToInt32(Session["UserId"]); 

        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("UPDATE Members SET FirstName=@FirstName,LastName=@LastName,DOB=@DOB,Address=@Address,Suburb=@Suburb,City=@City,ZipCode=@ZipCode,Phone=@Phone,Email=@Email,Username=@Username,Password=@Password,HearAboutUs=@HearAboutUs,ContactEmail=@ContactEmail,ContactPhone=@ContactPhone,ContactLetter=@ContactLetter WHERE Id=@ID", sqlConn);
        sqlcmd.Parameters.AddWithValue("@ID", ID);
        sqlcmd.Parameters.AddWithValue("@FirstName", TextBoxFirstName.Text);
        sqlcmd.Parameters.AddWithValue("@LastName", TextBoxLastName.Text);
        sqlcmd.Parameters.AddWithValue("@DOB", sqlFormattedDate);
        sqlcmd.Parameters.AddWithValue("@Address", TextBoxAddress.Text);
        sqlcmd.Parameters.AddWithValue("@Suburb", TextBoxSuburb.Text);
        sqlcmd.Parameters.AddWithValue("@City", TextBoxCity.Text);
        sqlcmd.Parameters.AddWithValue("@ZipCode", TextBoxZipCode.Text);
        sqlcmd.Parameters.AddWithValue("@Phone", TextBoxPhone.Text);
        sqlcmd.Parameters.AddWithValue("@Email", TextBoxEmail.Text);
        sqlcmd.Parameters.AddWithValue("@Username", TextBoxUsername.Text);
        sqlcmd.Parameters.AddWithValue("@Password", TextBoxPassword.Text);
        sqlcmd.Parameters.AddWithValue("@HearAboutUs", DropDownListHearAbout.SelectedValue);
        sqlcmd.Parameters.AddWithValue("@ContactEmail", CheckBoxEmail.Checked);
        sqlcmd.Parameters.AddWithValue("@ContactPhone", CheckBoxPhone.Checked);
        sqlcmd.Parameters.AddWithValue("@ContactLetter", CheckBoxLetter.Checked);

        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            LabelUpdate.Visible = true;
            TextBoxFirstName.Enabled = false;
            TextBoxLastName.Enabled = false;
            TextBoxDOB.Enabled = false;
            TextBoxAddress.Enabled = false;
            TextBoxSuburb.Enabled = false;
            TextBoxCity.Enabled = false;
            TextBoxZipCode.Enabled = false;
            TextBoxPhone.Enabled = false;
            TextBoxEmail.Enabled = false;
            TextBoxUsername.Enabled = false;
            TextBoxPassword.Enabled = false;
            DropDownListHearAbout.Enabled = false;
            CheckBoxEmail.Enabled = false;
            CheckBoxPhone.Enabled = false;
            CheckBoxLetter.Enabled = false;
            ButtonRegister.Visible = false;
            UpdateDetails.Visible = true;
            Label1.Visible = false;

        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();

        }

    }
    protected void UpdateDetails_Click(object sender, EventArgs e)
    {
        TextBoxFirstName.Enabled = true;
        TextBoxLastName.Enabled = true;
        TextBoxDOB.Enabled = true;
        TextBoxAddress.Enabled = true;
        TextBoxSuburb.Enabled = true;
        TextBoxCity.Enabled = true;
        TextBoxZipCode.Enabled = true;
        TextBoxPhone.Enabled = true;
        TextBoxEmail.Enabled = true;
        TextBoxUsername.Enabled = true;
        TextBoxPassword.Enabled = true;
        DropDownListHearAbout.Enabled = true;
        CheckBoxEmail.Enabled = true;
        CheckBoxPhone.Enabled = true;
        CheckBoxLetter.Enabled = true;
        ButtonRegister.Visible = true;
        UpdateDetails.Visible = false;
        Label1.Visible = true;

    }
    protected void ButtonBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Index.aspx");

    }
}
