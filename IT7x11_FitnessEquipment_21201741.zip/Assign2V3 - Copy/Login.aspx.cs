﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;


public partial class Login : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {

    }
    protected void ButtonLogin_Click(object sender, EventArgs e)
    {
        if (TextBoxUsername.Text == "")
        {
            TextBoxUsernameValidate.Visible = true;
            return;
        }
        if (TextBoxPassword.Text == "")
        {
            TextBoxPasswordValidate.Visible = true;
            return;
        }
       
        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT *FROM Members WHERE username='" + TextBoxUsername.Text + "'AND password = '" + TextBoxPassword.Text + "'", sqlConn);
        SqlDataReader MyDataReader;



        try
        {

            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();
            if (MyDataReader.HasRows)
            {

                Session["username"] = MyDataReader["username"].ToString();
                Session["UserId"] = MyDataReader["id"].ToString();
                Response.Redirect("Index.aspx");
            }
            else
            {
                Response.Write("<script language='javascript'> alert('Login Failed. Please Try Again');</script>");
            }

        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();
        }
        //Con.Open();

        //cmd.Connection = Con;
        //cmd.CommandText = "SELECT *FROM Members WHERE username='" + TextBoxUsername.Text + "'AND password = '" + TextBoxPassword.Text + "'";
        //dr = cmd.ExecuteReader();
        //dr.Read();

        //if (dr.HasRows)
        //{

        //    Session["username"] = dr["username"].ToString();
        //    Session["UserId"] = dr["id"].ToString();
        //    Response.Redirect("Index.aspx");
        //}
        //else
        //{
        //    Response.Write("<script language='javascript'> alert('Login Failed. Please Try Again');</script>");
        //}

        //Con.Close();

    }
}