﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Configuration;


public partial class Index : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        LoadImage3();
        LoadImage4();
        LoadImage2();
        LoadImage1();


    }

    protected void LoadImage1()
    {
        SqlConnection sqlConn2 = new SqlConnection(MyConnStr);
        SqlCommand cmd2 = new SqlCommand("select top 1* from [Products] order by newid()", sqlConn2);
        SqlDataReader MyDataReader2;
        sqlConn2.Open();
        MyDataReader2 = cmd2.ExecuteReader();
        MyDataReader2.Read();
        string ID = MyDataReader2["Id"].ToString();
        Label1.Text = MyDataReader2["Name"].ToString();
        Label2.Text = MyDataReader2["Price"].ToString();

        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT Id FROM Products where Id = '" + ID + "'", sqlConn);
        SqlDataReader MyDataReader;


        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();

            string id = MyDataReader["Id"].ToString();
            Image1.Visible = id != "0";
            if (id != "0")
            {
                byte[] bytes = (byte[])GetData("SELECT Data FROM Products WHERE Id =" + id).Rows[0]["Data"];
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                Image1.ImageUrl = "data:image/png;base64," + base64String;
            }


            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }
}
    protected void LoadImage2()
    {
        SqlConnection sqlConn2 = new SqlConnection(MyConnStr);
        SqlCommand cmd2 = new SqlCommand("select top 1* from [Products] order by newid()", sqlConn2);
        SqlDataReader MyDataReader2;
        sqlConn2.Open();
        MyDataReader2 = cmd2.ExecuteReader();
        MyDataReader2.Read();
        string ID = MyDataReader2["Id"].ToString();
        Label3.Text = MyDataReader2["Name"].ToString();
        Label4.Text = MyDataReader2["Price"].ToString();

        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT Id FROM Products where Id = '" + ID + "'", sqlConn);
        SqlDataReader MyDataReader;


        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();

            string id = MyDataReader["Id"].ToString();
            Image2.Visible = id != "0";
            if (id != "0")
            {
                byte[] bytes = (byte[])GetData("SELECT Data FROM Products WHERE Id =" + id).Rows[0]["Data"];
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                Image2.ImageUrl = "data:image/png;base64," + base64String;
            }


            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }
    }

    protected void LoadImage3()
    {
        SqlConnection sqlConn2 = new SqlConnection(MyConnStr);
        SqlCommand cmd2 = new SqlCommand("select top 1* from [Products] order by newid()", sqlConn2);
        SqlDataReader MyDataReader2;
        sqlConn2.Open();
        MyDataReader2 = cmd2.ExecuteReader();
        MyDataReader2.Read();
        string ID = MyDataReader2["Id"].ToString();
        Label5.Text = MyDataReader2["Name"].ToString();
        Label6.Text = MyDataReader2["Price"].ToString();

        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT Id FROM Products where Id = '" + ID + "'", sqlConn);
        SqlDataReader MyDataReader;


        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();

            string id = MyDataReader["Id"].ToString();
            Image3.Visible = id != "0";
            if (id != "0")
            {
                byte[] bytes = (byte[])GetData("SELECT Data FROM Products WHERE Id =" + id).Rows[0]["Data"];
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                Image3.ImageUrl = "data:image/png;base64," + base64String;
            }


            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }
    }

    protected void LoadImage4()
    {
        SqlConnection sqlConn2 = new SqlConnection(MyConnStr);
        SqlCommand cmd2 = new SqlCommand("select top 1* from [Products] order by newid()", sqlConn2);
        SqlDataReader MyDataReader2;
        sqlConn2.Open();
        MyDataReader2 = cmd2.ExecuteReader();
        MyDataReader2.Read();
        string ID = MyDataReader2["Id"].ToString();
        Label7.Text = MyDataReader2["Name"].ToString();
        Label8.Text = MyDataReader2["Price"].ToString();

        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT Id FROM Products where Id = '" + ID + "'", sqlConn);
        SqlDataReader MyDataReader;


        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();

            string id = MyDataReader["Id"].ToString();
            Image4.Visible = id != "0";
            if (id != "0")
            {
                byte[] bytes = (byte[])GetData("SELECT Data FROM Products WHERE Id =" + id).Rows[0]["Data"];
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                Image4.ImageUrl = "data:image/png;base64," + base64String;
            }


            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }
    }


    private DataTable GetData(string query)
    {
        DataTable dt = new DataTable();
        using (SqlConnection con = new SqlConnection(MyConnStr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    sda.Fill(dt);
                }
            }
            return dt;
        }
    }
 

}