﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Configuration;
using System.IO;


public partial class Admin_Company : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FirstEntry();
        }
        FileUpload1.Visible = false;

        if (Session["username"] == null)
        {
            Response.Redirect("Index.aspx");
        }
        
    }

    protected void FirstEntry()
    {
        //buttonActive(false, true, false, true, false, true);

        SqlConnection sqlConn = new SqlConnection(MyConnStr);
        SqlCommand cmd = new SqlCommand("SELECT * FROM Company", sqlConn);
        SqlDataReader MyDataReader;

        try
        {
            sqlConn.Open();
            MyDataReader = cmd.ExecuteReader();
            MyDataReader.Read();

            TextBoxID.Text = MyDataReader["Id"].ToString();
            TextBoxPhone.Text = MyDataReader["Phone"].ToString();
            TextBoxAddress.Text = MyDataReader["Address"].ToString();
            FileUpload1.Visible = false;
            string id = TextBoxID.Text;
            Image1.Visible = id != "0";
            if (id != "0")
            {
                byte[] bytes = (byte[])GetData("SELECT Data FROM Company WHERE Id =" + id).Rows[0]["Data"];
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                Image1.ImageUrl = "data:image/png;base64," + base64String;
            }


            //Response.Write("<script language='javascript'> alert('Database connection openned');</script>");
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
            //Response.Write("<script language='javascript'> alert('Customer not found!');</script>");
        }
        finally
        {
            sqlConn.Close();
            //  Response.Write("<script language='javascript'> alert('Database connection closed');</script>");
        }
    }
 
    private DataTable GetData(string query)
    {
        DataTable dt = new DataTable();
        using (SqlConnection con = new SqlConnection(MyConnStr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    sda.Fill(dt);
                }
            }
            return dt;
        }
    }

   
    protected void ButtonEdit_Click(object sender, EventArgs e)
    {


        ButtonEdit.Visible = false;
        ButtonUpdate.Visible = true;
        TextBoxAddress.Enabled = true;
        TextBoxPhone.Enabled=true;
    }
    protected void ClearPanel()
    {
        TextBoxID.Text = "";
        TextBoxPhone.Text = "";
        TextBoxAddress.Text = "";

    }


    protected void ButtonUpdate_Click(object sender, EventArgs e)
    {

        if (TextBoxPhone.Text == "")
        {
            TextBoxPhoneValid.Visible = true;
            return;
        }
        if (TextBoxAddress.Text == "")
        {
            TextBoxAddressValid.Visible = true;
            return;
        }
        TextBoxPhoneValid.Visible = false;
        TextBoxAddressValid.Visible = false;
        int ID = 4;
        //Create q sql connection
        SqlConnection sqlConn = new SqlConnection(MyConnStr);

        //Create a sql statement
        SqlCommand sqlcmd = new SqlCommand("UPDATE Company SET Phone=@Phone,Address=@Address WHERE Id=@Id", sqlConn);
        sqlcmd.Parameters.AddWithValue("@Id", ID);
        sqlcmd.Parameters.AddWithValue("@Phone", TextBoxPhone.Text);
        sqlcmd.Parameters.AddWithValue("@Address", TextBoxAddress.Text);


        try
        {
            sqlConn.Open();
            sqlcmd.ExecuteNonQuery();
            TextBoxAddress.Enabled = false;
            TextBoxPhone.Enabled = false;
            LabelUpdate.Visible = true;
            ButtonUpdate.Visible = false;
            ButtonEdit.Visible = true;
        }
        catch (Exception er)
        {
            Response.Write("<script language='javascript'> alert('Database connection failed');</script>");
        }
        finally
        {
            sqlConn.Close();

        }

    }
    public bool True { get; set; }
    }
