﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Configuration;

public partial class Products : System.Web.UI.Page
{
    private string MyConnStr = WebConfigurationManager.ConnectionStrings["MyConnStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {


        BindingData();
        BindingDataWeights();
        BindingDataTreadmills();
        BindingDataExcercyles();
        BindingDataFootwearWomens();
        BindingDataApparelWomen();
        BindingDataApparelMen();
        BindingDataFootwearMens();

    }
    protected void BindingData()
    {

        DataTable dt = new DataTable();
        string strQuery = "select * from Products";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        BindingData();
    }
    protected void BindingDataWeights()
    {
        string Category = "Weights and Bars";
        DataTable dt = new DataTable();
        string strQuery = "select * from Products where category= '" + Category + "'";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView2.DataSource = dt;
            GridView2.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }

    }
    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView2.PageIndex = e.NewPageIndex;
        BindingDataWeights();
    }
    protected void BindingDataTreadmills()
    {
        string Category = "Treadmills";
        DataTable dt = new DataTable();
        string strQuery = "select * from Products where category= '" + Category + "'";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView3.DataSource = dt;
            GridView3.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }

    }
    protected void GridView3_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView3.PageIndex = e.NewPageIndex;
        BindingDataTreadmills();
    }
    protected void BindingDataExcercyles()
    {
        string Category = "Excercyles";
        DataTable dt = new DataTable();
        string strQuery = "select * from Products where category= '" + Category + "'";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView4.DataSource = dt;
            GridView4.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }

    }
    protected void GridView4_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView4.PageIndex = e.NewPageIndex;
        BindingDataExcercyles();
    }
    protected void BindingDataFootwearWomens()
    {
        string Category = "Footwear";
        string SubCategory = "Womens";
        DataTable dt = new DataTable();
        string strQuery = "select * from Products where category= '" + Category + "' AND SubCategory='" + SubCategory + "'";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView5.DataSource = dt;
            GridView5.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }
    }
    protected void GridView5_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView5.PageIndex = e.NewPageIndex;
        BindingDataFootwearWomens();
    }
    protected void BindingDataFootwearMens()
    {
        string Category = "Footwear";
        string SubCategory = "Mens";
        DataTable dt = new DataTable();
        string strQuery = "select * from Products where category= '" + Category + "' AND SubCategory='" + SubCategory + "'";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView8.DataSource = dt;
            GridView8.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }
    }
    protected void GridView8_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView8.PageIndex = e.NewPageIndex;
        BindingDataFootwearWomens();
    }
    protected void BindingDataApparelWomen()
    {
        string Category = "Apparel";
        string SubCategory = "Womens";
        DataTable dt = new DataTable();
        string strQuery = "select * from Products where category= '" + Category + "' AND SubCategory='" + SubCategory + "'";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView6.DataSource = dt;
            GridView6.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }

    }
    protected void GridView6_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView6.PageIndex = e.NewPageIndex;
        BindingDataApparelWomen();
    }
    protected void BindingDataApparelMen()
    {
        string Category = "Apparel";
        string SubCategory = "Mens";
        DataTable dt = new DataTable();
        string strQuery = "select * from Products where category= '" + Category + "' AND SubCategory='" + SubCategory + "'";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlConnection con = new SqlConnection(MyConnStr);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView7.DataSource = dt;
            GridView7.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }

    }
    protected void GridView7_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView6.PageIndex = e.NewPageIndex;
        BindingDataApparelMen();
    }
}